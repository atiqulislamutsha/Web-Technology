<ul style="text-align: right;">
        <a href="../view/addemployee.php"> Add Employee</a>&emsp;&emsp;
        <a href="../view/showAllemployee.php"> Show All Employee</a>&emsp;&emsp;
        <a href="../view/searchemployee.php"> Search Employee</a>
    </ul>