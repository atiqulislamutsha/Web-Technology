<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Background Color</title>
</head>

<body style =" Background-color:green"></style>

</body>
</html>